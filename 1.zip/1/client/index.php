<?php include("head.php"); ?>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- PRE LOADER -->
<div class="preloader">
  <div class="cssload-dots">
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
  </div>
</div>

<!-- Navigation Section -->
<?php include("menu.php"); ?>

<!-- Home Section -->
<div id="home" class="parallax-section"> 
  <!--     <div class="overlay"></div>-->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-1 col-md-10 col-sm-12">
        <div class="slide-text">
          <h3>What we offer? <a href="#" class="typewrite" data-period="2000" data-type='[ "Car Rental", "Special Rates", "One Way Rental", "City to City", "Free Rides" ]'> <span class="wrap"></span> </a> </h3>
          <h1>Welcome to Car Rental Template!</h1>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
          <a href="#about" class="btn btn-default section-btn">Get Started</a> </div>
      </div>
    </div>
  </div>
</div>

<!-- Form Section -->
<div class="container">
  <div class="bformBox">
    <h3>BOOK YOUR CAR TODAY!</h3>
    <form action="http://sharjeelanjum.com/html/car-rental/html/booking.php" method="POST">
      <div class="formrow">
        <select class="form-control" name="car_type" >
          <option value="" >Select Your Car For Booking</option>
          <option>BMW</option>
          <option>Honda</option>
          <option>Toyota</option>
          <option>Nissan</option>
          <option>Chrysler</option>
          <option>Chevrolet</option>
          <option>Mercedes</option>
          <option>Volvo</option>
          <option>Suzuki</option>
        </select>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i> Pick-Up</span>
              <select class="form-control" data-live-search="true" name="pickup" id="pickup" required="required" >
                <option value="">Select Pick-Up</option>
                <option>New York</option>
                <option>Los Angeles</option>
                <option>Houston</option>
                <option>San Diego</option>
                <option>Chicago</option>
                <option>California</option>
                <option>San Jose</option>
                <option>Atlanta</option>
                <option>Kansas City</option>
                <option>Chattanooga</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group date form_datetime" data-date="2018-02-22T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1">
              <input class="form-control" size="16" type="text" value="" readonly placeholder="Select Date and Time" name="datetime_pick" required >
              <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span> <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span> </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i> Drop-Off</span>
              <select class="form-control" data-live-search="true" name="dropoff" id="drop" required="required">
                <option value="" >Select Drop-Off</option>
                <option>New York</option>
                <option>Los Angeles</option>
                <option>Houston</option>
                <option>San Diego</option>
                <option>Chicago</option>
                <option>California</option>
                <option>San Jose</option>
                <option>Atlanta</option>
                <option>Kansas City</option>
                <option>Chattanooga</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group date form_datetime" data-date="2018-02-22T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1">
              <input class="form-control" size="16" type="text" value="" readonly placeholder="Select Date and Time" name="datetime_off" required >
              <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span> <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span> </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="text" class="form-control" placeholder="Your Name" name="name" required >
          </div>
        </div>
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="email" class="form-control" placeholder="Your Email" name="email" required>
          </div>
        </div>
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="text" class="form-control" placeholder="Phone" name="phone" required>
          </div>
        </div>
      </div>
      <div class="formbtn">
        <input type="submit" class="btn" value="Submit Car Booking">
      </div>
    </form>
  </div>
</div>

<!-- Cars Section -->
<div class="parallax-section" id="cars">
  <div class="container">
    <div class="section-title">
      <h3>Vehicle Models <span>For Rent</span></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce aliquet, massa ac ornare feugiat, nunc dui auctor ipsum, sed posuere eros sapien id quam. Maecenas odio nisi, efficitur eget</p>
    </div>
    <div class="vehiclesList">
      <ul class="carsmodals">
        <li class="item">
          <div class="row">
            <div class="col-md-3">
              <h3>BMW 3-SERIES</h3>
              <div class="subtitle">ModernLine</div>
              <div class="carPrice"> <strong>$99</strong> <span>/Day</span> </div>
              <a href="#" class="btn"><i class="fa fa-calendar" aria-hidden="true"></i> Reserve Now</a> </div>
            <div class="col-md-6"><a href="images/cars/01.jpg" class="image-popup"><img src="images/cars/01.jpg" alt="" /></a></div>
            <div class="col-md-3">
              <div class="carinfo">
                <ul>
                  <li>Doors: <strong>4</strong></li>
                  <li>Passengers: <strong>5</strong></li>
                  <li>Luggage: <strong>2 Bags</strong></li>
                  <li>Transmission: <strong>Automatic</strong></li>
                  <li>Air conditioning: <strong>Dual Zone</strong></li>
                  <li>Minimum age: <strong>35 years</strong></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
        <li class="item">
          <div class="row">
            <div class="col-md-3">
              <h3>Subaru Impreza</h3>
              <div class="subtitle">Premium</div>
              <div class="carPrice"> <strong>$125</strong> <span>/Day</span> </div>
              <a href="#" class="btn"><i class="fa fa-calendar" aria-hidden="true"></i> Reserve Now</a> </div>
            <div class="col-md-6"><a href="images/cars/02.jpg" class="image-popup"><img src="images/cars/02.jpg" alt="" /></a></div>
            <div class="col-md-3">
              <div class="carinfo">
                <ul>
                  <li>Doors: <strong>4</strong></li>
                  <li>Passengers: <strong>5</strong></li>
                  <li>Luggage: <strong>2 Bags</strong></li>
                  <li>Transmission: <strong>Automatic</strong></li>
                  <li>Air conditioning: <strong>Dual Zone</strong></li>
                  <li>Minimum age: <strong>35 years</strong></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
        <li class="item">
          <div class="row">
            <div class="col-md-3">
              <h3>Hyundai Santa Fe XL</h3>
              <div class="subtitle">Streetsville H</div>
              <div class="carPrice"> <strong>$199</strong> <span>/Day</span> </div>
              <a href="#" class="btn"><i class="fa fa-calendar" aria-hidden="true"></i> Reserve Now</a> </div>
            <div class="col-md-6"><a href="images/cars/03.jpg" class="image-popup"><img src="images/cars/03.jpg" alt="" /></a></div>
            <div class="col-md-3">
              <div class="carinfo">
                <ul>
                  <li>Doors: <strong>4</strong></li>
                  <li>Passengers: <strong>5</strong></li>
                  <li>Luggage: <strong>2 Bags</strong></li>
                  <li>Transmission: <strong>Automatic</strong></li>
                  <li>Air conditioning: <strong>Dual Zone</strong></li>
                  <li>Minimum age: <strong>35 years</strong></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
        <li class="item">
          <div class="row">
            <div class="col-md-3">
              <h3>Honda Vizel</h3>
              <div class="subtitle">Streetsville H</div>
              <div class="carPrice"> <strong>$215</strong> <span>/Day</span> </div>
              <a href="#" class="btn"><i class="fa fa-calendar" aria-hidden="true"></i> Reserve Now</a> </div>
            <div class="col-md-6"><a href="images/cars/04.jpg" class="image-popup"><img src="images/cars/04.jpg" alt="" /></a></div>
            <div class="col-md-3">
              <div class="carinfo">
                <ul>
                  <li>Doors: <strong>4</strong></li>
                  <li>Passengers: <strong>5</strong></li>
                  <li>Luggage: <strong>2 Bags</strong></li>
                  <li>Transmission: <strong>Automatic</strong></li>
                  <li>Air conditioning: <strong>Dual Zone</strong></li>
                  <li>Minimum age: <strong>35 years</strong></li>
                </ul>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</div>

<!-- Service 1 -->

<!-- About section -->


<!-- Counter Section -->
<div id="counter">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-3 col-xs-12 counter-item">
        <div class="counterbox">
          <div class="counter-icon"><i class="fa fa-users" aria-hidden="true"></i></div>
          <span class="counter-number" data-from="1" data-to="499" data-speed="1000"></span> <span class="counter-text">Happy Client</span> </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 counter-item">
        <div class="counterbox">
          <div class="counter-icon"><i class="fa fa-car" aria-hidden="true"></i></i></div>
          <span class="counter-number" data-from="1" data-to="199" data-speed="2000"></span> <span class="counter-text">Cars</span> </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 counter-item">
        <div class="counterbox">
          <div class="counter-icon"><i class="fa fa-map-signs" aria-hidden="true"></i></div>
          <span class="counter-number" data-from="1" data-to="50" data-speed="3000"></span> <span class="counter-text">Destinations</span> </div>
      </div>
      <div class="col-md-3 col-sm-3 col-xs-12 counter-item">
        <div class="counterbox">
          <div class="counter-icon"><i class="fa fa-trophy" aria-hidden="true"></i></div>
          <span class="counter-number" data-from="1" data-to="199" data-speed="4000"></span> <span class="counter-text">Awards</span> </div>
      </div>
    </div>
  </div>
</div>

<!-- Service Section -->


<!-- Blog Section -->

<!-- Newsletter-->
<div class="newsletter">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <h3>Newsletter</h3>
        <p>Subscribe for our weekly newsletter.</p>
      </div>
      <div class="col-md-8">
        <div class="input-group">
          <input type="text" class="form-control" placeholder="Enter Your Email Address">
          <span class="input-group-btn">
          <button class="btn btn-secondary" type="button">Sign Up <i class="fa fa-paper-plane" aria-hidden="true"></i></button>
          </span> </div>
      </div>
    </div>
  </div>
</div>

<!-- Google Map Section -->
<div id="map"></div>

<!-- Contact Section -->
<div id="contact">
  <div class="container"> 
    
    <!-- Dection Title -->
    <div class="section-title" >
      <h3>Contact <span>Us</span></h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce aliquet, massa ac ornare feugiat, nunc dui auctor ipsum, sed posuere eros sapien id quam. Maecenas odio nisi, efficitur eget.</p>
    </div>
    
    <!-- CONTACT FORM HERE -->
    <div class="row">
      <div class="col-md-8">
        <div class="contact-form">
          <form id="contact-form" class="row" action="http://sharjeelanjum.com/html/car-rental/html/feedback.php" method="POST">
            <div class="col-md-6 col-sm-6">
              <input type="text" class="form-control" name="name" placeholder="Name" required  >
            </div>
            <div class="col-md-6 col-sm-6">
              <input type="email" class="form-control" name="email" placeholder="Email" required >
            </div>
            <div class="col-md-6 col-sm-12">
              <input type="tel" class="form-control" name="phone" placeholder="Phone">
            </div>
            <div class="col-md-6 col-sm-12">
              <input type="text" class="form-control" name="address" placeholder="Address">
            </div>
            <div class="col-md-12 col-sm-12">
              <textarea class="form-control" rows="5" name="message" placeholder="Message"></textarea>
            </div>
            <div class="col-md-12">
              <button id="submit" type="submit" class="form-control" name="submit">Send Message</button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-4">
        <div class="contact-now">
          <div class="contact"> <span><i class="fa fa-home"></i></span>
            <div class="information"> <strong>Address:</strong>
              <p>8500 lorem, New Ispum, Dolor amet sit 12301</p>
            </div>
          </div>
          <!-- Contact Info -->
          <div class="contact"> <span><i class="fa fa-envelope"></i></span>
            <div class="information"> <strong>Email Address:</strong>
              <p>investigate@your-site.com</p>
              <p>investigate@your-site.com</p>
            </div>
          </div>
          <!-- Contact Info -->
          <div class="contact"> <span><i class="fa fa-phone"></i></span>
            <div class="information"> <strong>Phone No:</strong>
              <p>+12 345 67 09</p>
              <p>+12 345 67 09</p>
            </div>
          </div>
          <!-- Contact Info --> 
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Clients Logo-->

<!-- Clients Logo end--> 

<!-- Footer Section -->
<footer>
  <div class="container"> 
    <!-- social Section -->
    <div class="socialLinks" > <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a> </div>
    <div class="row">
      <div class="col-md-12 col-sm-12">
        <div class="footer-copyright">
          <p>&copy; 2018 Car Rentals | All Rights Reserved.</p>
        </div>
      </div>
    </div>
  </div>
</footer>

<!-- Bootstrap --> 
<script src="js/jquery-2.1.4.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js" charset="UTF-8"></script> 

<!-- Popup --> 
<script src="js/jquery.magnific-popup.min.js"></script> 
<script src="js/magnific-popup-options.js"></script> 

<!-- Carousel --> 
<script src="js/owl.carousel.js"></script> 

<!-- Sticky Header --> 
<script src="js/jquery.sticky.js"></script> 

<!-- Parallax --> 
<script src="js/jquery.parallax.js"></script> 

<!-- Counter --> 
<script src="js/counter.js"></script> 
<script src="js/smoothscroll.js"></script> 

<!-- Google Map --> 
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAMqMG_n4C0aAi3F8a82Q6s3hxDLrTXxe8&amp;callback=initMap" async defer></script> 
<script src="js/gmap.js"></script> 

<!-- Custom --> 
<script src="js/custom.js"></script>
</body>

<!-- Mirrored from sharjeelanjum.com/html/car-rental/html/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Feb 2018 03:26:10 GMT -->
</html>