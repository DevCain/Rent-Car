<?php   include("../include/config.php"); ?>
<?php   include("../include/session.php"); ?>
<?php   include("../include/destory.php"); ?>
<?php   $msg=" "; ?>
    

<?php
  if(!empty($_POST)){
    $sql  = "INSERT INTO `client` (`nom`, `prenom`, `cin`, `tele`, `mail`, `adresse`, `id_agence`) VALUES ('".mysql_real_escape_string($_POST['nom'])."','".mysql_real_escape_string($_POST['prenom'])."','".mysql_real_escape_string($_POST['cin'])."','".mysql_real_escape_string($_POST['tele'])."','".mysql_real_escape_string($_POST['mail'])."','".mysql_real_escape_string($_POST['adresse'])."','".$_SESSION['id']."')";
    $resultas=mysql_query($sql);

    $msg=" Votre Client a bien été Ajouté ! Merci d'avoir utilisé notre systeme d'assistance.";
  }
?>
<?php include("include/head.php"); ?>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- PRE LOADER -->
<div class="preloader">
  <div class="cssload-dots">
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
  </div>
</div>

<!-- Navigation Section -->
<?php include("include/menu.php"); ?>

<!-- Home Section -->
<div id="home" class="parallax-section"> 
  <!--     <div class="overlay"></div>-->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-1 col-md-10 col-sm-12">
        <div class="bformBox" style="margin-top: 80px">
          <h3>Ajouter un Client</h3>
            <div class="formbtn">
              <a href="index.php" type="submit" class="btn">Afficher vos Clients</a>
              <a href="client_add.php" type="submit" class="btn">Ajouter un Client</a>
              <a href="client_update.php" type="submit" class="btn">Modifier un Client</a>
            </div>
            <br>
            <p><?php echo $msg; ?></p>
            <br>
          <form action="client_add.php" method="POST">
            <div class="row">
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="Prenom" name="prenom"  >
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="Nome" name="nom"  >
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="email" class="form-control" placeholder="E-mail" name="mail" >
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="Phone" name="tele" >
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="CIN" name="cin"  >
                </div>
              </div>
              <div class="col-md-6 col-sm-6">
                <div class="formrow">
                  <input type="text" class="form-control" placeholder="Adresse" name="adresse" >
                </div>
              </div>
            </div>
            <div class="formbtn">
              <input type="submit" class="btn" name="client_add" value="Ajouter">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include("include/footer.php"); ?>