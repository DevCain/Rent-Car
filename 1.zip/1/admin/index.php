<?php   include("../include/config.php"); ?>
<?php   include("../include/session.php"); ?>
<?php   include("../include/destory.php"); ?>
<?php   $msg=" "; ?>
<?php include("include/head.php"); ?>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- PRE LOADER -->
<div class="preloader">
  <div class="cssload-dots">
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
  </div>
</div>

<!-- Navigation Section -->
<?php include("include/menu.php"); ?>

<!-- Home Section -->
<div id="home" class="parallax-section"> 
  <!--     <div class="overlay"></div>-->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-1 col-md-10 col-sm-12">
        <div class="bformBox" style="margin-top: 80px">
    <h3>Afficher vos Clients</h3>
      <div class="formbtn">
        <a href="index.php" type="submit" class="btn">Afficher vos Clients</a>
        <a href="client_add.php" type="submit" class="btn">Ajouter un Client</a>
        <a href="client_update.php" type="submit" class="btn">Modifier un Client</a>
      </div>
      <br>
      <p><?php echo $msg; ?></p>
      <br>
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script> 

    <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Nom</th>
                <th>Prenom</th>
                <th>CIN</th>
                <th>Telephone</th>
                <th>E-Mail</th>
                <th>Adresse</th>
            </tr>
        </thead>
        <tbody>
<?php
  $r1 = "select * from `client` where id_agence='".$_SESSION['id']."'";  
  $resultas=mysql_query($r1);
  while($la_case=mysql_fetch_array($resultas)) {
  echo"
            <tr>
                <td>".$la_case['nom']." </td>
                <td>".$la_case['prenom']." </td>
                <td>".$la_case['cin']." </td>
                <td>".$la_case['tele']." </td>
                <td>".$la_case['mail']." </td>
                <td>".$la_case['adresse']." </td>
            </tr> 
    ";
  }
?>
        </tbody>
        <tfoot>
            <tr>
                <th>Nom</th>
                <th>Prenom</th>
                <th>CIN</th>
                <th>Telephone</th>
                <th>E-Mail</th>
                <th>Adresse</th>
            </tr>
        </tfoot>
    </table>
  </div>
      </div>
    </div>
  </div>
</div>

<?php include("include/footer.php"); ?>