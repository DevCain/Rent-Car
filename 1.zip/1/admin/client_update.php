<?php   include("../include/config.php"); ?>
<?php   include("../include/session.php"); ?>
<?php   include("../include/destory.php"); ?>
<?php   $msg=" "; ?>
<?php include("include/head.php"); ?>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">

<!-- PRE LOADER -->
<div class="preloader">
  <div class="cssload-dots">
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
    <div class="cssload-dot"></div>
  </div>
</div>

<!-- Navigation Section -->
<?php include("include/menu.php"); ?>

<!-- Home Section -->
<div id="home" class="parallax-section"> 
  <!--     <div class="overlay"></div>-->
  <div class="container">
    <div class="row">
      <div class="col-md-offset-1 col-md-10 col-sm-12">
        <div class="bformBox" style="margin-top: 80px">
    <h3>Modifier un Client</h3>
      <div class="formbtn">
        <a href="index.php" type="submit" class="btn">Afficher vos Clients</a>
        <a href="client_add.php" type="submit" class="btn">Ajouter un Client</a>
        <a href="client_update.php" type="submit" class="btn">Modifier un Client</a>
      </div>
      <br>
      <p><?php echo $msg; ?></p>
      <br>
    <form action="http://sharjeelanjum.com/html/car-rental/html/booking.php" method="POST">
      <div class="formrow">
        <select class="form-control" name="car_type" >
          <option value="" >Select Your Car For Booking</option>
          <option>BMW</option>
          <option>Honda</option>
          <option>Toyota</option>
          <option>Nissan</option>
          <option>Chrysler</option>
          <option>Chevrolet</option>
          <option>Mercedes</option>
          <option>Volvo</option>
          <option>Suzuki</option>
        </select>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i> Pick-Up</span>
              <select class="form-control" data-live-search="true" name="pickup" id="pickup" required="required" >
                <option value="">Select Pick-Up</option>
                <option>New York</option>
                <option>Los Angeles</option>
                <option>Houston</option>
                <option>San Diego</option>
                <option>Chicago</option>
                <option>California</option>
                <option>San Jose</option>
                <option>Atlanta</option>
                <option>Kansas City</option>
                <option>Chattanooga</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group date form_datetime" data-date="2018-02-22T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1">
              <input class="form-control" size="16" type="text" value="" readonly placeholder="Select Date and Time" name="datetime_pick" required >
              <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span> <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span> </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group"> <span class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i> Drop-Off</span>
              <select class="form-control" data-live-search="true" name="dropoff" id="drop" required="required">
                <option value="" >Select Drop-Off</option>
                <option>New York</option>
                <option>Los Angeles</option>
                <option>Houston</option>
                <option>San Diego</option>
                <option>Chicago</option>
                <option>California</option>
                <option>San Jose</option>
                <option>Atlanta</option>
                <option>Kansas City</option>
                <option>Chattanooga</option>
              </select>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-sm-6">
          <div class="formrow">
            <div class="input-group date form_datetime" data-date="2018-02-22T05:25:07Z" data-date-format="dd MM yyyy - HH:ii p" data-link-field="dtp_input1">
              <input class="form-control" size="16" type="text" value="" readonly placeholder="Select Date and Time" name="datetime_off" required >
              <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span> <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span> </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="text" class="form-control" placeholder="Your Name" name="name" required >
          </div>
        </div>
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="email" class="form-control" placeholder="Your Email" name="email" required>
          </div>
        </div>
        <div class="col-md-4 col-sm-4">
          <div class="formrow">
            <input type="text" class="form-control" placeholder="Phone" name="phone" required>
          </div>
        </div>
      </div>
      <div class="formbtn">
        <input type="submit" class="btn" value="Submit Car Booking">
      </div>
    </form>
  </div>
      </div>
    </div>
  </div>
</div>

<?php include("include/footer.php"); ?>