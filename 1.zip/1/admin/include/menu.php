<div class="navbar custom-navbar wow fadeInDown" data-wow-duration="2s" role="navigation" id="header">
  <div class="container"> 
    
    <!-- NAVBAR HEADER -->
    <div class="navbar-header">
      <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"> <span class="icon icon-bar"></span> <span class="icon icon-bar"></span> <span class="icon icon-bar"></span> </button>
      <!-- lOGO TEXT HERE --> 
      <a href="index.html" class="navbar-brand">Car <span>Rental</span></a> </div>
    
    <!-- NAVIGATION LINKS -->
    <div class="collapse navbar-collapse">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#home" class="smoothScroll">Home</a></li>
        <li><a href="#cars" class="smoothScroll">Cars</a></li>
        <li><a href="#about" class="smoothScroll">About</a></li>
        <li><a href="#service" class="smoothScroll">Service</a></li>
        <li><a href="#team" class="smoothScroll">Support</a></li>
        <li><a href="#testimonials" class="smoothScroll">Clients</a></li>
        <li><a href="#contact" class="smoothScroll">Contact</a></li>
        <li><span class="calltxt"><i class="fa fa-phone" aria-hidden="true"></i> 123 456 7890</span></li>
      </ul>
    </div>
  </div>
</div>