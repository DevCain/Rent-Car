<?php
 if ($_SESSION['type']<>"aal" and $_SESSION['type']<>"admin")header('Location:../index.php');
?>