 <script language="javascript" type='text/javascript'>
    function session(){
        window.location="../deconnexion.php"; //page de déconnexion
    }
    setTimeout("session()",240000); //ça fait bien 4min??? c'est pour le test
</script>
