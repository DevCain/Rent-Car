-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2018 at 10:13 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `car`
--

-- --------------------------------------------------------

--
-- Table structure for table `aal`
--

CREATE TABLE `aal` (
  `id` int(11) NOT NULL,
  `commune` text NOT NULL,
  `aal` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aal`
--

INSERT INTO `aal` (`id`, `commune`, `aal`) VALUES
(3, 'khouribga', 'aakh1'),
(4, 'khouribga', 'aakh2'),
(5, 'khouribga', 'aakh3'),
(6, 'khouribga', 'aakh4'),
(7, 'khouribga', 'aakh5'),
(8, 'khouribga', 'aakh6'),
(9, 'khouribga', 'aakh7'),
(10, 'oued_zem', 'aaod1'),
(11, 'oued_zem', 'aaod2'),
(12, 'oued_zem', 'aaod3'),
(13, 'oued_zem', 'aaod4'),
(14, 'el_fokra', 'el_fokra'),
(24, 'bejaad', 'aabj1'),
(25, 'bejaad', 'aabj2'),
(26, 'boujniba', 'boujniba'),
(27, 'hattane', 'hattane'),
(28, 'ouled_abdoune', 'ouled_abdoune'),
(29, 'ouled_azzouz', 'ouled_azzouz'),
(31, 'lagfaf', 'lagfaf'),
(32, 'boulanouar', 'boulanouar'),
(35, 'bni_bataou', 'bni_bataou'),
(36, 'chougrane', 'chougrane'),
(37, 'm_fassis', 'el_fokra'),
(38, 'ouled_ftata', 'bnikhirane'),
(39, 'ouled_boughadi', 'bnikhirane'),
(40, 'ait_ammar', 'bnikhirane'),
(41, 'lagnadiz', 'bnikhirane'),
(42, 'bni_zrantel', 'bni_bataou'),
(43, 'boukhraiss', 'bni_bataou'),
(44, 'ouled_gouaouch', 'bni_bataou'),
(45, 'bir_mezoui', 'boulanouar'),
(46, 'rouached', 'chougrane'),
(47, 'tachraft', 'chougrane'),
(48, 'ait_kaicher', 'chougrane'),
(49, 'ouled_fennane', 'smaala'),
(50, 'maadna', 'smaala'),
(51, 'kesbat_troch', 'smaala'),
(52, 'ouled_aissa', 'smaala'),
(53, 'braksa', 'smaala'),
(54, 'bni_ykhlef', 'lagfaf'),
(55, 'bni_smir', 'bni_smir');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `nom` text,
  `prenom` text,
  `cin` text,
  `tele` text,
  `mail` text,
  `adresse` text,
  `id_agence` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `nom`, `prenom`, `cin`, `tele`, `mail`, `adresse`, `id_agence`) VALUES
(24, 'ppp', 'ppp', 'pp', 'ppp', '', 'pppp', 37),
(23, 'sss', 'sss', 'ss', 'sss', '', 'ssss', 39),
(22, 'hghg', 'hg', 'nn', 'kkk', 'hg@kk', 'nnnnnnn', 37),
(21, '', '', '', '', '', '', 37),
(20, 'dfdf', NULL, NULL, NULL, NULL, NULL, 37),
(25, '', 'h', '', '', '', '', 37),
(26, 'said', 'said', 'said', 'said', 'said@said.com', 'said', 37),
(27, '', 'xxxx', '', '', '', '', 39);

-- --------------------------------------------------------

--
-- Table structure for table `table_name`
--

CREATE TABLE `table_name` (
  `id` int(11) NOT NULL,
  `intitule` text,
  `cout` text,
  `credit` text,
  `maitrise` text,
  `etat_physique` text,
  `etat_financier` text,
  `partenaire` text,
  `date` text,
  `delai` text,
  `observation` text,
  `commune` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table_name`
--

INSERT INTO `table_name` (`id`, `intitule`, `cout`, `credit`, `maitrise`, `etat_physique`, `etat_financier`, `partenaire`, `date`, `delai`, `observation`, `commune`) VALUES
(1, 'hghghg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `login` text NOT NULL,
  `password` text NOT NULL,
  `type` text NOT NULL,
  `aal` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `login`, `password`, `type`, `aal`) VALUES
(3, 'client1', 'client1', 'client', 'khouribga'),
(39, 'admin2', 'admin2', 'admin', ''),
(38, 'client2', 'client2', 'client', ''),
(37, 'admin', 'admin', 'admin', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aal`
--
ALTER TABLE `aal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table_name`
--
ALTER TABLE `table_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aal`
--
ALTER TABLE `aal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `table_name`
--
ALTER TABLE `table_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
