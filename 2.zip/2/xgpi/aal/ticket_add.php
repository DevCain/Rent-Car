<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php
	if(!empty($_POST)){

		$sql  = "INSERT INTO `intervention` (`titre`, `urgence`, `description`, `informaticien`, `demandeur`, `division`, `service`, `statut`, `date_start`, `date_end`) VALUES ('".mysql_real_escape_string($_POST['titre'])."','".$_POST['urgence']."','".mysql_real_escape_string($_POST['description'])."','".$_POST['informaticien']."','".$_POST['demandeur']."','".$_POST['division']."','".$_POST['service']."','".$_POST['statut']."','".$_POST['date_start']."','".$_POST['date_end']."')";
		$resultas=mysql_query($sql);

		$msg=" Votre ticket a bien été enregistré ! Merci d'avoir utilisé notre systeme d'assistance.";
	}
?>				
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
										<h2 id="elements">Creer un Ticket</h2>
										<?php
											if(!empty($_POST)) echo "<b>".$msg."<b><a href='index.php'> Retour</a>";
										?>
										<div class="row 200%">
											<div class="12u 12u$(medium)">	
													<form enctype="multipart/form-data" action="ticket_add.php" method="POST" name="projet_add">
														<div class="row uniform">
															  														
															<div class="6u 12u$(xsmall)">
		<input type="text" name="titre" id="demo-name" value="" placeholder="Titre" maxlength="60" required />
															</div>
															<div class="6u 12u$(xsmall)">
																<div class="select-wrapper">
																	<select name="urgence" id="demo-category">
																		<option type="text" class="form-control1"  value="Moyenne" selected>Urgence</option>
																		<option type='text' class='form-control1'  value="Tres haute">Tres haute</option>
																		<option type='text' class='form-control1'  value="Haute">Haute</option>
																		<option type='text' class='form-control1'  value="Moyenne">Moyenne</option>
																		<option type='text' class='form-control1'  value="Basse">Basse</option>
																		<option type='text' class='form-control1'  value="Tres basse">Tres basse</option>
																	</select>
																</div>
															</div>
															<div class="12u 12u$(xsmall)">
		<input type="text" name="description" id="demo-name" value="" placeholder="Description" maxlength="1000" required />
															</div>

															<input type="hidden" name="informaticien" value="" />
															<input type="hidden" name="demandeur" value='<?php echo $_SESSION['login'] ?>' />
															<input type="hidden" name="division" value='<?php echo $_SESSION['division'] ?>' />
															<input type="hidden" name="service" value='<?php echo $_SESSION['service'] ?>' />
															<input type="hidden" name="statut" value="Nouveau" />
															<input type="hidden" name="date_start" value='<?php echo date("d/m/Y"); ?>' />
															<input type="hidden" name="date_end" value="" />
															<div class="12u$">
																<ul class="actions">
																	<li><input type="submit" value="Soumettre la demande" class="special" /></li>
																</ul>
															</div> 
														</div>
													</form>
											</div>
										</div>
								</section>
						</div>
					</div>
<?php  	include("include/menu.php"); ?>				