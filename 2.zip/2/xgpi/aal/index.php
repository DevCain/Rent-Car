<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
										<h2 id="elements">Statut</h2>
										<div class='row 200%'>
											<div class='12u 12u$(medium)'>
											<div class="table-wrapper">
														<table class="alt">
															<thead>
																<tr>
																	<th><h4>Tickets</h4></th>																
																	<th><h4>Nombre</h4></th>
																</tr>
															</thead>														
									
				<?php 
						$r1 = "select count(`statut`) AS nouveau , statut from `intervention` where `demandeur`='".$_SESSION['login']."' and `statut` = 'nouveau' ";
						$resultas=mysql_query($r1);
						$cpt=0;
						$msg = "";
						while($la_case=mysql_fetch_array($resultas)) 
						{
							$msg = $msg."
															<tbody>
																<tr>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>Nouveau</a></td>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>".$la_case['nouveau']."</a></td>
																</tr>
															</tbody>
									";
							$cpt++;
						}
						if($cpt!= 0) echo $msg;
				

				?>
				<?php 
						$r1 = "select count(`statut`) AS en_cours , statut from `intervention` where `demandeur`='".$_SESSION['login']."' and `statut` = 'en_cours' ";
						$resultas=mysql_query($r1);
						$cpt=0;
						$msg = "";
						while($la_case=mysql_fetch_array($resultas)) 
						{
							$msg = $msg."
															<tbody>
																<tr>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>En cours</a></td>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>".$la_case['en_cours']."</a></td>
																</tr>
															</tbody>
									";
							$cpt++;
						}
						if($cpt!= 0) echo $msg;
				

				?>
				<?php 
						$r1 = "select count(`statut`) AS en_attente , statut from `intervention` where `demandeur`='".$_SESSION['login']."' and `statut` = 'en_attente' ";
						$resultas=mysql_query($r1);
						$cpt=0;
						$msg = "";
						while($la_case=mysql_fetch_array($resultas)) 
						{
							$msg = $msg."
															<tbody>
																<tr>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>En attente</a></td>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>".$la_case['en_attente']."</a></td>
																</tr>
															</tbody>
									";
							$cpt++;
						}
						if($cpt!= 0) echo $msg;
				

				?>
				<?php 
						$r1 = "select count(`statut`) AS resole , statut from `intervention` where `demandeur`='".$_SESSION['login']."' and `statut` = 'resole' ";
						$resultas=mysql_query($r1);
						$cpt=0;
						$msg = "";
						while($la_case=mysql_fetch_array($resultas)) 
						{
							$msg = $msg."
															<tbody>
																<tr>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>Résolu</a></td>
			<td><a href='ticket_statut.php?statut=".$la_case['statut']."'>".$la_case['resole']."</a></td>
																</tr>
															</tbody>
									";
							$cpt++;
						}
						if($cpt!= 0) echo $msg;
				

				?>
											</table>
													</div></div>
										</div>
								</section>

						</div>
					</div>
<?php  	include("include/menu.php"); ?>	
			<!--<div class='3u 12u$(xsmall)'>
				<input type='text' id='demo-name' value=".$la_case['commune']." disabled='disabled' />
			</div>-->			