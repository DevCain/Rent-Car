<!-- Sidebar -->
					<div id="sidebar">
						<div class="inner">

							<!-- Search -->
								<section id="search" class="alt">
									<form method="post" action="#">
										<input type="text" name="query" id="query" placeholder="Search" />
									</form>
								</section>

							<!-- Menu -->
								<nav id="menu">
									<header class="major">
										<h4>Menu</h4>
									</header>
									<ul>
										<li><a href="index.php">Home</a></li>
										<li><a href="ticket.php">Tickets</a></li>
										<li><a href="ticket_add.php">Creer un Ticket</a></li>									
									</ul>
								</nav>



<!-- Section -->
								<section>
									<header class="major">
										<h4>About App </h4>
									</header>
									<p>GPI - Gestion Parc Informatique de la Province de Khouribga.</br>
									</p>
									
								</section>

							<!-- Footer -->
								<footer id="footer">
									<center><p class="copyright">Designed by SSIC Khouribga</a>. </br>GPI &copy; 2018</p></center>
								</footer>

						</div>
					</div>

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>

	</body>
</html>