<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php
	if(!empty($_POST)){

		$sql  = "INSERT INTO `suivi`(`id_t`, `login`, `msg`, `date`) VALUES ('".$_POST['id_t']."','".$_POST['login']."','".mysql_real_escape_string($_POST['msg'])."','".$_POST['date']."')";

		$resultas=mysql_query($sql);
		header('Location: ticket_detail.php?id='.$_POST['id_t'].'');
	}
?>				
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
										<h2 id="elements">Ajouter un suivi</h2>
										<div class="row 200%">
											<div class="12u 12u$(medium)">	
				<form enctype="multipart/form-data" action="suivi_add.php" method="POST" name="projet_add">
														<div class="row uniform">  												

															<div class="12u 12u$(xsmall)">
		<input type="text" name="msg" id="demo-name" value="" placeholder="Votre Message de Suivi" maxlength="1000" required />
															</div>


		<input type="hidden" name="id_t" value='<?php echo $_GET['id_t'] ?>' />
		<input type="hidden" name="login" value='<?php echo $_SESSION['login'] ?>' />
		<input type="hidden" name="date" value='<?php echo date("d/m/Y h:i:sa"); ?>' />
													
															<div class="12u$">
																<ul class="actions">
																	<li><input type="submit" value="Soumettre la demande" class="special" /></li>
																</ul>
															</div> 
														</div>
													</form>
											</div>
										</div>
								</section>
						</div>
					</div>
<?php  	include("include/menu.php"); ?>				