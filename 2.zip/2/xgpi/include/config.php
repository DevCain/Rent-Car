<?php
	$host="localhost";
	$db="gpi";
	$user="root";
	$passwd="";

	$connection= mysql_connect($host,$user,$passwd) or DIE ("pas de serveur");

	mysql_select_db($db) or DIE ("pas de base de donnés");
session_start();
?>