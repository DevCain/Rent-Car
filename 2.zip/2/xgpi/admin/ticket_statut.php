<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
										<h2 id="elements">Statut</h2>
										<div class='row 200%'>
											<div class='12u 12u$(medium)'>
											<div class="table-wrapper">
														<table class="alt">
															<thead>
																<tr>
																	<th><h4>Titre</h4></th>				
																	<th><h4>Demandeur</h4></th>
																	<th><h4>Informaticien</h4></th>
																	<th><h4>date d'ouverture</h4></th>
																</tr>
															</thead>														
									
				<?php 
$r1 = "select * from `intervention` where `statut` = '".$_GET['statut']."' ";
						$resultas=mysql_query($r1);
						$cpt=0;
						$msg = "";
						while($la_case=mysql_fetch_array($resultas)) 
						{
							$msg = $msg."
															<tbody>
																<tr>
							<td><a href='ticket_detail.php?id=".$la_case['id']."'>".$la_case['titre']."</a></td>
							<td><a href='ticket_detail.php?id=".$la_case['id']."'>".$la_case['demandeur']."</a></td>
							<td><a href='ticket_detail.php?id=".$la_case['id']."'>".$la_case['informaticien']."</a></td>
							<td><a href='ticket_detail.php?id=".$la_case['id']."'>".$la_case['date_start']."</a></td>
																</tr>
															</tbody>
									";
							$cpt++;
						}
						if($cpt!= 0) echo $msg;
				

				?>
				
											</table>
													</div></div>
										</div>
								</section>

						</div>
					</div>
<?php  	include("include/menu.php"); ?>	
			<!--<div class='3u 12u$(xsmall)'>
				<input type='text' id='demo-name' value=".$la_case['commune']." disabled='disabled' />
			</div>-->			