<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php
	if(!empty($_POST)){

		$sql  = "UPDATE `intervention` SET `urgence`='".$_POST['urgence']."',`informaticien`='".$_POST['informaticien']."',`statut`='".$_POST['statut']."',`date_end`='".$_POST['date_end']."' WHERE `id`='".$_POST['id_t']."' ";

		$resultas=mysql_query($sql);
		header('Location: ticket_detail.php?id='.$_POST['id_t'].'');
	}
?>				
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
										<h2 id="elements">Affecter</h2>
										<div class="row 200%">
											<div class="12u 12u$(medium)">	
				<form enctype="multipart/form-data" action="ticket_affecter.php" method="POST" name="projet_add">
														<div class="row uniform">  												
		<input type="hidden" name="id_t" value='<?php echo $_GET['id_t'] ?>' />													

															<div class="4u 12u$(xsmall)">
																<div class="select-wrapper">
																	<select name="urgence" id="demo-category">
																		<option type="text" class="form-control1"  value="Moyenne" selected>Urgence</option>
																		<option type='text' class='form-control1'  value="Tres haute">Tres haute</option>
																		<option type='text' class='form-control1'  value="Haute">Haute</option>
																		<option type='text' class='form-control1'  value="Moyenne">Moyenne</option>
																		<option type='text' class='form-control1'  value="Basse">Basse</option>
																		<option type='text' class='form-control1'  value="Tres basse">Tres basse</option>
																	</select>
																</div>
															</div>

															<div class="4u 12u$(xsmall)">
																<div class="select-wrapper">
																	<select name="statut" id="demo-category">
						<option type="text" class="form-control1"  value="Nouveau" selected>Nouveau</option>
						<option type='text' class='form-control1'  value="En_cours">En cours</option>
						<option type='text' class='form-control1'  value="En_attente">En attente</option>
						<option type='text' class='form-control1'  value="Resole">Résolu</option>
																	</select>
																</div>
															</div>

															<div class="4u 12u$(xsmall)">
																<div class="select-wrapper">
																	<select name="informaticien" id="demo-category">
						<option type="text" class="form-control1"  value="melmasbahi" selected>ELMASBAHI</option>
						<option type='text' class='form-control1'  value="mnafli">NAFLI</option>
						<option type='text' class='form-control1'  value="nhitaf">Nabil HITAF</option>
						<option type='text' class='form-control1'  value="ielferkh">Issam EL FERKH</option>
																	</select>
																</div>
															</div>
		<input type="hidden" name="date_end" value='<?php echo date("d/m/Y"); ?>' />
													
															<div class="12u$">
																<ul class="actions">
													<li><input type="submit" value="Affecter" class="special" /></li>
																</ul>
															</div> 
														</div>
				</form>
											</div>
											</div>
										</div>
								</section>
						</div>
					</div>
<?php  	include("include/menu.php"); ?>				