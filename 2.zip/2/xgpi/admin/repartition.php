<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									

<!-- chart start -->
<?php
					
						$r1 = "SELECT * FROM `intervention`";	
						$resultas=mysql_query($r1);
						$Nouveau = 0;
						$En_cours = 0;
						$En_attente = 0;
						$Resole = 0;
						
						while($la_case=mysql_fetch_array($resultas)) {

							switch ($la_case['statut']) {
							    case "Nouveau":
							        $Nouveau = $Nouveau + 1;
							        break;
							    case "En_cours":
							        $En_cours = $En_cours + 1;
							        break;
							    case "En_attente":
							        $En_attente = $En_attente + 1;
							        break;
							    case "Resole":
							        $Resole = $Resole + 1;
							        break;
							}									
						}

				?>

<script src="code/highcharts.js"></script>
<script src="code/modules/exporting.js"></script>

<div id="container" style="min-width: 310px; height: 400px; max-width: 600px; margin: 0 auto"></div>



		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'Repartition des Tickets par Statut'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },

	series: [{
        name: 'soit',
        colorByPoint: true,
        data: [
        {
            name: 'Nouveau, <?php echo $Nouveau ; ?>',
            y: <?php echo $Nouveau ; ?>
        }, 
        {
            name: 'En cours, <?php echo $En_cours ; ?>',
            y: <?php echo $En_cours ; ?>,
            sliced: true,
            selected: true
        }, 
        {
            name: 'En attente, <?php echo $En_attente ; ?>',
            y: <?php echo $En_attente ; ?>
        },
        {
            name: 'Resole, <?php echo $Resole ; ?>',
            y: <?php echo $Resole ; ?>
        },  

        ]
    }]


});
		</script>



<!-- chart end -->
								</section>

						</div>
					</div>
<?php  	include("include/menu.php"); ?>	
			<!--<div class='3u 12u$(xsmall)'>
				<input type='text' id='demo-name' value=".$la_case['commune']." disabled='disabled' />
			</div>-->			