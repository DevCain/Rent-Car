<?php  	include("../include/config.php"); ?>
<?php  	include("../include/session.php"); ?>
<?php  	include("../include/destory.php"); ?>
<?php  	include("include/header.php"); ?>				
							<!-- Content -->
								<section>
									<!-- Elements -->
<form action="ticket_affecter.php" enctype="multipart/form-data" method="GET">
									<input type="hidden" name="id_t" value='<?php echo $_GET['id'] ?>' />

									<div class="12u$">
										<ul class="actions">
											<li><input type="submit" value="Affecter" class="special" /></li>
										</ul>
									</div>
								</section>
								</form>									
<?php

						$r1 = "select * from `intervention` where id='".$_GET['id']."'";	
						$resultas=mysql_query($r1);
						while($la_case=mysql_fetch_array($resultas)) {
							echo"
									<h2 id='elements'>Ticket N: ".$la_case['id']."</h2>
										<div class='row 200%'>
											<div class='12u 12u$(medium)'>	
														<div class='row uniform'>
															<div class='4u 12u$(xsmall)'>
																<b>Titre</b>: ".$la_case['titre']."
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Urgence</b>: ".$la_case['urgence']."
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Statut</b>: ".$la_case['statut']." 
															</div>

															<div class='4u 12u$(xsmall)'>
																<b>Demandeur</b>: ".$la_case['demandeur']." 
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Division</b>: ".$la_case['division']."
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Service</b>: ".$la_case['service']."
															</div>

															<div class='4u 12u$(xsmall)'>
																<b>Informaticien</b>: ".$la_case['informaticien']." 
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Date d'ouverture</b>: ".$la_case['date_start']."
															</div>
															<div class='4u 12u$(xsmall)'>
																<b>Derniere mise a jour</b>: ".$la_case['date_end']." 
															</div>

															<div class='12u 12u$(xsmall)'>
																<b>Description</b>: ".$la_case['description']." 
															</div>
														</div>
											</div>
										</div>
									";
						}
?>

<?php
						$r1 = "select * from `suivi` where id_t='".$_GET['id']."'";	
						$resultas=mysql_query($r1);
						while($la_case=mysql_fetch_array($resultas)) {
							echo"
									<header id='header'>
										<a class='logo'>Suivi de: '' ".$la_case['login']." ''</a>
									</header>										
										<div class='row 200%'>
											<div class='12u 12u$(medium)'>	
														<div class='row uniform'>
															<div class='12u 12u$(xsmall)'>
					<img src='images/chat.png' width='30' height='30'>&nbsp;&nbsp;&nbsp;".$la_case['date']."
					</br>".$la_case['msg']." 
															</div>
														</div>
											</div>
										</div>
									";
						}

?>
								</br></br>
								<form action="suivi_add.php" enctype="multipart/form-data" method="GET">
									<input type="hidden" name="id_t" value='<?php echo $_GET['id'] ?>' />

									<div class="12u$">
										<ul class="actions">
											<li><input type="submit" value="Ajouter un suivi" class="special" /></li>
										</ul>
									</div>
								</section>
								</form>
								

						</div>
					</div>
<?php  	include("include/menu.php"); ?>	
			<!--<div class='3u 12u$(xsmall)'>
				<input type='text' id='demo-name' value=".$la_case['commune']." disabled='disabled' />
			</div>-->			