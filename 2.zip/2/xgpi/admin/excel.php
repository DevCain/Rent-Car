<?php  	include("../include/config.php"); ?>
<?php  
$output = '';

 $query = "SELECT * FROM `intervention` ";
 $result = mysql_query($query);
 if(mysql_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1"> 
                    <tr>  
                         <th>ID</th>  
                         <th>Titre</th>
                         <th>Urgence</th>  
                         <th>Description</th>
                         <th>Informaticien</th>  
                         <th>Demandeur</th>  
                         <th>Division</th>
                         <th>Service</th>  
                         <th>Statut</th>
                         <th>Date d\'ouverture</th>  
                         <th>Derniere mise a jour</th>  
                    </tr>
  ';
  while($row = mysql_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["id"].'</td>  
                         <td>'.$row["titre"].'</td>  
                         <td>'.$row["urgence"].'</td> 
                         <td>'.$row["description"].'</td>  
                         <td>'.$row["informaticien"].'</td>  
                         <td>'.$row["demandeur"].'</td> 
                         <td>'.$row["division"].'</td>  
                         <td>'.$row["service"].'</td>  
                         <td>'.$row["statut"].'</td> 
                         <td>'.$row["date_start"].'</td>  
                         <td>'.$row["date_end"].'</td>  
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }

?>